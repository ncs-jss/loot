package com.example.dell.loot;

public class Endpoints {
    public static String syncRequest = "http://52.91.35.65:8080/api/users/";
    public static String register = "http://52.91.35.65:8080/api/users/register/";
    public static String leaders = "http://52.91.35.65:8080/api/users/leaderboard/";
    public static String fetchMission = "git";
    public static String updateUser = "http://52.91.35.65:8080/api/users/";
    public static String send = "http://52.91.35.65:8080/";
    public static String duel = "http://52.91.35.65:8080/api/duels/";
    public static String apikey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFkbWluIiwicGFzc3dvcmQiOiJsb290MjAxOSIsImlhdCI6MTU0ODMxMzI2Mn0.VqN0AmH6URo8z_zPff68C81a8e5EUYPgOrwU18TvLMU";
}
